<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\ProductType;

class ProductController extends Controller
{
    //
    public function getListProduct(){
        $product = Product::orderBy('id','DESC')->paginate(10);
        $theloai = \App\Producttype::all();
        
        return view('admin.products.list_product',['product'=>$product,'theloai'=>$theloai]);
    }

    public function getEditProduct($id){

        $product = Product::find($id);
        $theloai = ProductType::all();
        return view('admin.products.edit_product',['product'=>$product,'theloai'=>$theloai]);
    }

    public function postEditProduct(Request $req,$id){
        $pr = Product::find($id);
        $this->validate($req,
        ['TheLoai'=>'required',
        'tensp'=>'required|min:3',
        'mota'=>'required',  
        ],
        [
            'TheLoai.required'=>'Bạn cần chọn nhà sản xuất.',
            'tensp.required'=>"Bạn cần nhập lại tên Laptop.",
            
            'mota.required'=>'Bạn cần nhập mô tả.'
        ]);
        $pr->name = $req->tensp;
        $pr->id_type = $req->TheLoai;
        $pr->description = $req->mota;
        $pr->unit_price = $req->unit_price;
        $pr->promotion_price = $req->promotion_price;
        if($req->hasFile('hinhsp')){
            $file= $req->file('hinhsp');
            $duoi = $file->getClientOriginalExtension();
            if($duoi != 'jpg' && $duoi != 'png' && $duoi != 'jpeg'){
                return redirect()->back()->with('thongbao','Lỗi định dạng hình ảnh !!!');
            }
            $name = $file->getClientOriginalName();
            $Hinh = str_random(4)."_". $name;
            while(file_exists("source/image/".$Hinh))
            {
                $Hinh = str_random(4)."_". $name;
            }
            
            $file->move("source/image/product",$Hinh);
            //unlink("source/image/product".$pr->Hinh);
            $pr->image = $Hinh;
           // echo $Hinh;
        }
        $pr->new = $req->new;
        
        $pr->created_at = date('Y-m-d');
        $pr->updated_at = date('Y-m-d');
        $pr->QTY = $req->qty;
           

        $pr->save();

        return redirect()->back()->with('thongbao','Đã sửa thành công');
        
    }

    public function getAddProduct(){

        $theloai = ProductType::all();
        //return $theloai;
        return view('admin.products.add_product',['theloai'=>$theloai]);
    }

    public function postAddProduct(Request $req){
        $this->validate($req,
        ['TheLoai'=>'required',
        'tensp'=>'required|min:3',
        'mota'=>'required',  
        ],
        [
            'TheLoai.required'=>'Bạn cần chọn nhà sản xuất.',
            'tensp.required'=>"Bạn cần nhập lại tên Laptop.",
            
            'mota.required'=>'Bạn cần nhập mô tả.'
        ]);

        $pr = new Product;
        $pr->name = $req->tensp;
        $pr->id_type = $req->TheLoai;
        $pr->description = $req->mota;
        $pr->unit_price = $req->unit_price;
        $pr->promotion_price = $req->promotion_price;
        if($req->hasFile('hinhsp')){
            $file= $req->file('hinhsp');
            $duoi = $file->getClientOriginalExtension();
            if($duoi != 'jpg' && $duoi != 'png' && $duoi != 'jpeg'){
                return redirect()->back()->with('thongbao','Lỗi định dạng hình ảnh !!!');
            }
            $name = $file->getClientOriginalName();
            $Hinh = str_random(4)."_". $name;
            while(file_exists("source/image/".$Hinh))
            {
                $Hinh = str_random(4)."_". $name;
            }
            $file->move("source/image/product",$Hinh);
            $pr->image = $Hinh;
           // echo $Hinh;
        }else {
            $pr->image="";
        }
        $pr->new = $req->new;
        
        $pr->created_at = date('Y-m-d');
        $pr->updated_at = date('Y-m-d');
        $pr->QTY = $req->qty;
           

        $pr->save();
            return redirect('admin/products/add-product')->with('thongbao','Thêm thành công');
        //return redirect()->back()->with('thongbao','Thêm thành công');
    
    }

    public function getDelProduct($id){

        $product = Product::find($id);
        $product->delete();
        return redirect()->back()->with('thongbao','Đã xóa thành công');
    }
}
