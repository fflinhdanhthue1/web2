<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BillController extends Controller
{
    //
    public function getListBill(){
        return view('admin.Bills.listBill');
    }

    public function getEditBill(){
        return view('admin.Bills.editBill');
    }

    
}
