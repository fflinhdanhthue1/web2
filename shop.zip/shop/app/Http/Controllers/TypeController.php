<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ProductType;

class TypeController extends Controller
{
    //
    public function getListType(){
        $theloai = ProductType::paginate(5);
        return view('admin.type_products.list',['theloai'=>$theloai]);
    }

    public function getEditType($id){

        $theloai = ProductType::find($id);
        return view('admin.type_products.edit',['theloai'=>$theloai]);
    }

    public function postEditType(Request $req,$id){
        $theloai = ProductType::find($id);
        $this->validate($req,
        ['tenloai'=>'required|min:3|max:20'],
        ['tenloai.required'=>'Bạn cần nhập lại tên hãng',
        
        'tenloai.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
        'tenloai.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.']);

        $theloai->name = $req->tenloai;
        $theloai->description = $req->mota;
        $theloai->updated_at = date('Y-m-d');
        $theloai->save();

        return redirect()->back()->with('thongbao','Đã sửa thành công');
        
    }

    public function getAddType(){

        return view('admin.type_products.them');
    }

    public function postAddtype(Request $req){
        $this->validate($req,
        ['tenloai'=>'required|min:3|max:20'],
        [   'tenloai.required'=>'Bạn cần nhập lại tên hãng',
            
            'tenloai.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'tenloai.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.']);

        $theloai = new ProductType;
        $theloai->name = $req->tenloai;
        $theloai->description = $req->mota;
        $theloai->created_at = date('Y-m-d');
        $theloai->save();

        return redirect()->back()->with('thongbao','Thêm thành công');
    
    }

    public function getDelType($id){

        $theloai = ProductType::find($id);
        $theloai->delete();
        return redirect()->back()->with('thongbao','Đã xóa thành công');
    }
}
