<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use App\Customer;


class CustomerController extends Controller
{
    //
    public function getListCustomer(){
        $user = Customer::paginate(10);
        return view('admin.customers.listcustomer',['user'=>$user]);
    }

    public function getEditCustomer($id){
        $user = Customer::find($id);
        return view('admin.customers.editcustomer',['user'=>$user]);
    }

    public function postEditCustomer(Request $req,$id){
        $user = Customer::find($id);
        $this->validate($req,
        [
            'tenuser'=>'required|min:1|max:100',
            'address'=>'required|min:3|max:20',
            'phone_number'=>'required|min:3|max:20',
        ],
        [
            'tenuser.required'=>'Bạn cần nhập lại tên', 
            'tenuser.min'=>'Độ dài kí tự phải từ 1 đến 100 kí tự.',
            'tenuser.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'address.required'=>'Bạn cần nhập lại địa chỉ giao hàng', 
            'address.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'address.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'phone_number.required'=>'Bạn cần nhập lại số điện thoại liên hệ', 
            'phone_number.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'phone_number.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
        ]);
        $user->name = $req->tenuser;
        if(($req->gender) == 1 ){
            $user->gender = 'Nam';
        }else {
            $user->gender = 'Nữ';
        }
        
        $user->email = $req->email;
        $user->address = $req->address;
        $user->phone_number = $req->phone_number;
        $user->note = $req->note;
        //$user->created_at = date('Y-m-d');
        $user->updated_at = date('Y-m-d');
        $user->save();
        return redirect()->back()->with('thongbao','Đã sửa thành công');

    }
    public function getAddCustomer(){
        return view('admin.customers.addcustomer');
    }

    public function postAddCustomer(Request $req){
        $this->validate($req,
        [
            'tenuser'=>'required|min:3|max:20',
            'address'=>'required|min:3|max:20',
            'phone_number'=>'required|min:3|max:20',
        ],
        [
            'tenuser.required'=>'Bạn cần nhập lại tên', 
            'tenuser.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'tenuser.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'address.required'=>'Bạn cần nhập lại địa chỉ giao hàng', 
            'address.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'address.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'phone_number.required'=>'Bạn cần nhập lại số điện thoại liên hệ', 
            'phone_number.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'phone_number.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
        ]);
        $user = new Customer;
        $user->name = $req->tenuser;
        if(($req->gender) == 1 ){
            $user->gender = 'Nam';
        }else {
            $user->gender = 'Nữ';
        }
        
        $user->email = $req->email;
        $user->address = $req->address;
        $user->phone_number = $req->phone_number;
        $user->note = $req->note;
        $user->created_at = date('Y-m-d');
        $user->updated_at = date('Y-m-d');
        $user->save();

        return redirect()->back()->with('thongbao','Đã sửa thành công');
    }

    public function getDelCustomer($id){

        $user = Customer::find($id);
        $user->delete();
        return redirect()->back()->with('thongbao','Đã xóa thành công');
    }

    public function getdangnhapAdmin(){
        return view('admin.login');
    }

    public function postdangnhapAdmin(Request $req){
        $this->validate($req,
        [
            'email'=>'required',
            'password'=>'required|min:6|max:100',
        ],
        [   
            'email.required'=>'Bạn chưa nhập email',
            'password.required'=>'Bạn chưa nhập pass',
            'password.min'=>'Bạn cần nhập tối thiểu 6 kí tự',
            'password.max'=>'Bạn cần nhập tối đa 100 kí tự',

        ]);

        if(Auth::attemt(['email'=>$req->email,'password'=>$req->password])){
            return view('admin/products/list-product');
        }else{
            return view('admin/dangnhap')->with('thongbao','Đăng nhập không thành công');
        }

    }
}
