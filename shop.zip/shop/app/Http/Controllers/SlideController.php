<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\ProductType;
use App\Slide;

class SlideController extends Controller
{
    //
    public function getListSlide(){
        $slide = Slide::paginate(5);
        return view('admin.slides.listslide',['slide'=>$slide]);
    }

    public function getEditSlide($id){

        $slide = Slide::find($id);
        //$theloai = ProductType::all();
        return view('admin.Slides.editslide',['slide'=>$slide]);
    }

    public function postEditSlide(Request $req,$id){
        $slide = Slide::find($id);
        
        $slide->link = $req->link;
       
        if($req->hasFile('hinhsl')){
            $file= $req->file('hinhsp');
            $duoi = $file->getClientOriginalExtension();
            if($duoi != 'jpg' && $duoi != 'png' && $duoi != 'jpeg'){
                return redirect()->back()->with('thongbao','Lỗi định dạng hình ảnh !!!');
            }
            $name = $file->getClientOriginalName();
            $Hinh = str_random(4)."_". $name;
            while(file_exists("source/image/slide".$Hinh))
            {
                $Hinh = str_random(4)."_". $name;
            }
            
            $file->move("source/image/slide",$Hinh);
           
            $slide->image = $Hinh;
          
        }
        
           

        $slide->save();

        return redirect()->back()->with('thongbao','Đã sửa thành công');
        
    }

    public function getAddSlide(){

        return view('admin.slides.addslide');
    }

    public function postAddSlide(Request $req){
       

        $sl = new Slide;
        $sl->link = $req->link;
        if($req->hasFile('hinhsl')){
            $file= $req->file('hinhsl');
            $duoi = $file->getClientOriginalExtension();
            if($duoi != 'jpg' && $duoi != 'png' && $duoi != 'jpeg'){
                return redirect()->back()->with('thongbao','Lỗi định dạng hình ảnh !!!');
            }
            $name = $file->getClientOriginalName();
            $Hinh = str_random(4)."_". $name;
            while(file_exists("source/image/".$Hinh))
            {
                $Hinh = str_random(4)."_". $name;
            }
            $file->move("source/image/slide",$Hinh);
            $sl->image = $Hinh;
           // echo $Hinh;
        }else {
            $sl->image="";
        }

        $sl->created_at = date('Y-m-d');
        $sl->updated_at = date('Y-m-d');
        $sl->save();

        return redirect()->back()->with('thongbao','Thêm thành công');
    
    }

    public function getDelSlide($id){

        $slide = Slide::find($id);
        $slide->delete();
        return redirect()->back()->with('thongbao','Đã xóa thành công');
    }
}
