<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

use App\User;
use App\Product;
use App\ProductType;

class UserController extends Controller
{
    //
    public function getListUser(){
        $user = User::paginate(10);
        return view('admin.users.listuser',['user'=>$user]);
    }

    public function getEditUser($id){
        $user = User::find($id);
        return view('admin.users.edituser',['user'=>$user]);
    }

    public function postEditUser(Request $req,$id){
        $user = User::find($id);
        $this->validate($req,
        [
            'tenuser'=>'required|min:3|max:20',
            
            'password'=>'required|min:6|max:100',
           
           
            
        ],
        [
            'tenuser.required'=>'Bạn cần nhập lại tên', 
            'tenuser.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'tenuser.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'password.required'=>'Bạn cần nhập password',
            'password.min'=>'Password có ít nhất 6 kí tự',
            'password.max'=>'Password có tối đa 32 kí tự',
        ]);

        $user->full_name = $req->tenuser;
        $user->email = $req->email;
        if(($req->changepassword) == "on"){
            $user->password = bcrypt($req->password);
        }else {
            $user->password = $req->password;
        }
        $user->password = $req->password;
        if(($req->auth) == 1 ){
            $user->remember_token = 'Admin';
        }else {
            $user->remember_token = 'Thường';
        }
        $user->address = $req->diachi;
        $user->phone = $req->phone_number;
       
        //$user->created_at = date('Y-m-d');
        $user->updated_at = date('Y-m-d');
        $user->save();
        return redirect()->back()->with('thongbao','Đã sửa thành công');

    }
    public function getAddUser(){
        return view('admin.users.adduser');
    }

    public function postAddUser(Request $req){
        $this->validate($req,
        [
            'tenuser'=>'required|min:3|max:20',
            'email'=>'required|email|unique:users,email',
            'password'=>'required|min:6|max:100',
            'passwordagain'=>'required|same:password',
           
            'phone_number'=>'required|min:3|max:20',
        ],
        [
            'tenuser.required'=>'Bạn cần nhập lại tên', 
            'tenuser.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'tenuser.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'email.required'=>'Bạn cần nhập email',
            'email.email'=>'Bạn chưa nhập đúng định dạng của email',
            'email.unique'=>'Email đã tồn tại',
            'password.required'=>'Bạn cần nhập password',
            'password.min'=>'Password có ít nhất 6 kí tự',
            'password.max'=>'Password có tối đa 32 kí tự',

            'passwordagain.required'=>'Bạn chưa nhập lại xác thực password',
            'passwordagain.same'=>'Mật khẩu nhập lại không chính xác',
            
            'phone_number.required'=>'Bạn cần nhập lại số điện thoại liên hệ', 
            'phone_number.min'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
            'phone_number.max'=>'Độ dài kí tự phải từ 3 đến 20 kí tự.',
        ]);
        $user = new User;
        $user->full_name = $req->tenuser;
        
        
        $user->email = $req->email;
        $user->password = bcrypt($req->password);
        $user->phone = $req->phone_number;
        $user->address = $req->diachi;
        $user->remember_token = $req->auth;
        $user->created_at = date('Y-m-d');
        $user->updated_at = date('Y-m-d');
        $user->save();
            //return $user->address;
        return redirect()->back()->with('thongbao','Đã thêm thành công');
    }

    public function getDelUser($id){

        $user = User::find($id);
        $user->delete();
        return redirect()->back()->with('thongbao','Đã xóa thành công');
    }

    public function getdangnhapAdmin(){
        
        return view('admin.login');
    }

    public function postdangnhapAdmin(Request $req){
        $this->validate($req,
        [
            'email'=>'required',
            'password'=>'required|min:6|max:100',
        ],
        [   
            'email.required'=>'Bạn chưa nhập email',
            'password.required'=>'Bạn chưa nhập pass',
            'password.min'=>'Bạn cần nhập tối thiểu 6 kí tự',
            'password.max'=>'Bạn cần nhập tối đa 100 kí tự',

        ]);

       $email = $req->email;
       $password = $req->password;
       if (Auth::attempt(['email'=>$email,'password'=>$password])){
        $product = Product::orderBy('id','DESC')->paginate(10);
        $theloai = \App\Producttype::all();    
        return view('admin.products.list_product',['product'=>$product,'theloai'=>$theloai]);    
       }else {
           return redirect()->back()->with('thongbao','Email hoặc mật khẩu không chính xác');
       }
    
           
        /*if($user){
            if(Auth::attempt($credentials)){

            return view('admin/products/list-product');
            }
            else{
                return redirect()->back()->with(['flag'=>'thongbao','message'=>'Đăng nhập không thành công']);
            }
        }
        else{
           return redirect()->back()->with(['flag'=>'thongbao','message'=>'Tài khoản chưa kích hoạt']); 
        }*/

    }
}
